@echo off
title NoName Blur setup
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
pause
