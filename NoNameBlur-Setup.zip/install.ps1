﻿$ErrorActionPreference = "Stop"
$dir = Join-Path $env:LOCALAPPDATA "SmallUtils\Blur"
New-Item -ItemType Directory -Force -Path $dir | Out-Null
Copy-Item (Join-Path $PSScriptRoot "NoNameBlur.exe") $dir -Force

$sm = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"
$folder = Join-Path $sm "Мелкие утилиты"
New-Item -ItemType Directory -Force -Path $folder | Out-Null

$urlPath = Join-Path $folder "Мелкие утилиты.url"
$urlText = "[InternetShortcut]`r`nURL=https://nonameprojects.pages.dev/utils.html`r`n"
[System.IO.File]::WriteAllText($urlPath, $urlText, [System.Text.Encoding]::ASCII)

$ws = New-Object -ComObject WScript.Shell
$lnk = $ws.CreateShortcut((Join-Path $folder "NoName Blur.lnk"))
$lnk.TargetPath = Join-Path $dir "NoNameBlur.exe"
$lnk.WorkingDirectory = $dir
$lnk.Save()

Write-Host ""
Write-Host "Готово! Установлено в: $dir" -ForegroundColor Green
Write-Host "В Пуске появилась папка «Мелкие утилиты» (ссылка на страницу + NoName Blur)." -ForegroundColor Cyan
Write-Host "Запусти NoName Blur - она свернётся в трей, бинд: Ctrl+Alt+B." -ForegroundColor Cyan
